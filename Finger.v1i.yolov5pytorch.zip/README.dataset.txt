# Finger > 2024-02-16 1:53pm
https://universe.roboflow.com/ai01-dsbqj/finger-izdit

Provided by a Roboflow user
License: CC BY 4.0

